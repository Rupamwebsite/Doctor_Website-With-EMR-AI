const TOKEN_KEY = 'admin_token'; // এই নামটি doctors-master.html এর সাথে মিলতে হবে

// --- HTML এলিমেন্টগুলো ধরে ফেলা ---
const loginForm = document.getElementById('loginForm');
const adminKeyInput = document.getElementById('adminKey');
const loginButton = document.getElementById('loginButton');
const errorMsg = document.getElementById('error-msg');
const buttonText = loginButton.querySelector('.btn-text');

// --- Helper ফাংশন: লোডিং স্টেট দেখানো/লুকানো ---
function setLoading(isLoading) {
    if (isLoading) {
        loginButton.classList.add('loading'); // লোডার CSS চালু
        loginButton.disabled = true;          // বাটনটি নিষ্ক্রিয়
        errorMsg.style.display = 'none';      // পুরনো এরর লুকিয়ে ফেলা
    } else {
        loginButton.classList.remove('loading'); // লোডার CSS বন্ধ
        loginButton.disabled = false;           // বাটনটি আবার فعال
    }
}

// --- Helper ফাংশন: এরর দেখানো ---
function showError(message) {
    errorMsg.textContent = message;
    errorMsg.style.display = 'block';
}

// --- লগইন ফর্ম সাবমিট হলে ---
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const key = adminKeyInput.value.trim();

    if (!key) {
        showError('Please enter a key.');
        return;
    }

    setLoading(true); // ১. লোডিং শুরু

    try {
        // ২. কী (Key) টি সঠিক কিনা তা যাচাই করার চেষ্টা
        const response = await fetch('/api/admin/departments', {
            method: 'GET',
            headers: {
                'x-admin-key': key
            }
        });

        if (response.status === 401) {
            // ৩. কী ভুল হলে
            throw new Error('Invalid Admin Key. Please try again.');
        }
        
        if (!response.ok) {
            // ৪. অন্য কোনো সার্ভার এরর হলে (যেমন 500)
            throw new Error('Server error. Could not verify key.');
        }

        // ৫. কী সঠিক!
        localStorage.setItem(TOKEN_KEY, key); // কী সেভ করা
        buttonText.textContent = 'Success! Redirecting...'; // বাটন টেক্সট পরিবর্তন
        
        // ৬. অ্যাডমিন প্যানেলে রিডাইরেক্ট করা
        
        
        // 👇 ফিক্স: এখানে './admin' এর বদলে '/admin' ব্যবহার করা হয়েছে4
        
        window.location.href = './doctors-master.html';

    } catch (err) {
        // ৭. যেকোনো এরর হলে
        setLoading(false); // লোডিং বন্ধ
        showError(err.message); // এরর দেখানো
    }
});


(function checkLogin() {
    if (localStorage.getItem(TOKEN_KEY)) {
        
        fetch('/api/admin/departments', {
            method: 'GET',
            headers: { 'x-admin-key': localStorage.getItem(TOKEN_KEY) }
        }).then(res => {
            if (res.ok) {
                
                

                window.location.href = './doctors-master.html';
            } else {
                
                localStorage.removeItem(TOKEN_KEY);
            }
        });
    }
})();