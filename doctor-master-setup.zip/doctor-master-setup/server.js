require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const multer = require('multer');

const adminRoutes = require('./src/routes/adminRoutes');

// 1. DATABASE CONNECTIONS
const dbDoctor = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Rupam@123',
    database: 'd_doctor_master', 
    waitForConnections: true,
    connectionLimit: 5
});

const dbPatient = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Rupam@123',
    database: 'doctor_appoinment_db',
    waitForConnections: true,
    connectionLimit: 5
});

// 2. CONFIGURATION
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
const ABS_UPLOAD = path.join(__dirname, UPLOAD_DIR);
if (!fs.existsSync(ABS_UPLOAD)) fs.mkdirSync(ABS_UPLOAD, { recursive: true });

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, ABS_UPLOAD),
    filename: (req, file, cb) => cb(null, `doc-${Date.now()}${path.extname(file.originalname)}`)
});
const upload = multer({ storage: storage });

// Paths
const folderName = '../New Doctor_Appoinment System';
const rootPath = path.join(__dirname, folderName);
const publicInsidePath = path.join(__dirname, folderName, 'Public');
let landingPagePath = fs.existsSync(publicInsidePath) ? publicInsidePath : rootPath;
const dashboardPath = path.join(__dirname, '../Patient_Dashboard');
const adminPanelPath = path.join(__dirname, 'public');
const adminInnerPath = path.join(__dirname, 'public/admin'); 


// ============================================================
// 🏥 APP 2: ADMIN SERVER (Port 4000)
// ============================================================
const appAdmin = express();
appAdmin.use(cors());
appAdmin.use(express.json());
appAdmin.use(express.urlencoded({ extended: true }));

appAdmin.use(express.static(adminPanelPath)); 
appAdmin.use(express.static(adminInnerPath)); 
appAdmin.use('/uploads', express.static(ABS_UPLOAD)); 

appAdmin.get('/', (req, res) => res.redirect('/login.html'));
appAdmin.get('/login.html', (req, res) => {
    const f = path.join(adminInnerPath, 'login.html');
    if(fs.existsSync(f)) res.sendFile(f); else res.status(404).send('Login Not Found');
});
appAdmin.get('/doctors-master.html', (req, res) => {
    const f = path.join(adminInnerPath, 'doctors-master.html');
    if(fs.existsSync(f)) res.sendFile(f); else res.status(404).send('Dashboard Not Found');
});

// ⭐ MAIN API: DOCTOR LIST (Data Mapping Fixed) ⭐
appAdmin.get('/api/doctors', async (req, res) => {
    try {
        // ডাটাবেসের কলামের নাম -> ফ্রন্টএন্ডের ভেরিয়েবল নাম
        let query = `
            SELECT 
                DoctorID as id, 
                FirstName as first_name, 
                LastName as last_name,
                Department as department, 
                DoctorType as doctor_type, 
                Specialization as specialization,
                Fees as fees, 
                ContactNumber as phone, 
                Email as email, 
                image_url, 
                ActiveStatus as is_active,
                DOB as dob
            FROM doctors 
            ORDER BY DoctorID DESC
        `;
        const [rows] = await dbDoctor.promise().query(query);
        res.json({ doctors: rows });
    } catch (e) { 
        console.error(e);
        res.status(500).json({ error: e.message }); 
    }
});

// Single Doctor (For Edit)
appAdmin.get('/api/doctors/:id', async (req, res) => {
    try {
        const [rows] = await dbDoctor.promise().query(`
            SELECT DoctorID as id, FirstName as first_name, LastName as last_name, 
            Department as department, DoctorType as doctor_type, Specialization as specialization, 
            Fees as fees, ContactNumber as phone, Email as email, image_url, ActiveStatus as is_active, DOB as dob
            FROM doctors WHERE DoctorID = ?`, [req.params.id]);

        if (rows.length === 0) return res.status(404).json({ error: 'Not found' });
        res.json(rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// Create
appAdmin.post('/api/admin/doctors', upload.single('image'), async (req, res) => {
    try {
        const { first_name, last_name, department, specialization, fees, phone, email, doctor_type, dob } = req.body;
        const image = req.file ? req.file.filename : null;
        await dbDoctor.promise().query(
            `INSERT INTO doctors (FirstName, LastName, Department, Specialization, Fees, ContactNumber, Email, DoctorType, DOB, image_url, ActiveStatus) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
            [first_name, last_name, department, specialization, fees, phone, email, doctor_type, dob, image]
        );
        res.json({ message: 'Added' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// Update
appAdmin.put('/api/admin/doctors/:id', upload.single('image'), async (req, res) => {
    try {
        const { first_name, last_name, department, specialization, fees, phone, email, doctor_type, dob, is_active } = req.body;
        let query = `UPDATE doctors SET FirstName=?, LastName=?, Department=?, Specialization=?, Fees=?, ContactNumber=?, Email=?, DoctorType=?, DOB=?`;
        let params = [first_name, last_name, department, specialization, fees, phone, email, doctor_type, dob];

        if (req.file) {
            query += `, image_url=?`;
            params.push(req.file.filename);
        }
        
        // Active Status update handling
        if(is_active !== undefined) {
             query += `, ActiveStatus=?`;
             params.push(is_active === 'true' || is_active === '1' ? 1 : 0);
        }

        query += ` WHERE DoctorID=?`;
        params.push(req.params.id);

        await dbDoctor.promise().query(query, params);
        res.json({ message: 'Updated' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// Delete
appAdmin.delete('/api/admin/doctors/:id', async (req, res) => {
    try {
        await dbDoctor.promise().query('DELETE FROM doctors WHERE DoctorID = ?', [req.params.id]);
        res.json({ message: 'Deleted' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// Status Toggle
appAdmin.patch('/api/admin/doctors/:id/status', async (req, res) => {
    try {
        const { is_active } = req.body;
        await dbDoctor.promise().query('UPDATE doctors SET ActiveStatus = ? WHERE DoctorID = ?', [is_active, req.params.id]);
        res.json({ message: 'Status Updated' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// Master Data APIs
appAdmin.get('/api/master/departments', async (req, res) => {
    try {
        const [rows] = await dbDoctor.promise().query('SELECT * FROM departments ORDER BY name ASC');
        res.json(rows);
    } catch (e) { res.json([]); }
});
appAdmin.post('/api/master/departments', async (req, res) => {
    try {
        await dbDoctor.promise().query('INSERT INTO departments (name) VALUES (?)', [req.body.name]);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
appAdmin.get('/api/master/types', async (req, res) => {
    try {
        const [rows] = await dbDoctor.promise().query('SELECT * FROM doctor_types ORDER BY name ASC');
        res.json(rows);
    } catch (e) { res.json([]); }
});
appAdmin.post('/api/master/types', async (req, res) => {
    try {
        await dbDoctor.promise().query('INSERT INTO doctor_types (name) VALUES (?)', [req.body.name]);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});
appAdmin.get('/api/admin/departments', (req, res) => {
    // Admin Login Bypass
    if(req.headers['x-admin-key'] === 'my-secret-key') return res.json({list:[]});
    res.status(401).json({error:'Invalid'});
});

appAdmin.use('/api/admin', adminRoutes);


// ============================================================
// 🌍 APP 1: PATIENT SERVER (Port 3000)
// ============================================================
const appPublic = express();
appPublic.use(cors());
appPublic.use(express.json());
appPublic.use(express.urlencoded({ extended: true }));
appPublic.use(express.static(landingPagePath)); 
appPublic.use('/patient', express.static(dashboardPath)); 
appPublic.use('/uploads', express.static(ABS_UPLOAD)); 

appPublic.get('/', (req, res) => {
    const f = path.join(landingPagePath, 'index.html');
    if(fs.existsSync(f)) res.sendFile(f); else res.send('Landing Page Not Found');
});

appPublic.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        if(email === 'admin@hospital.com' && password === 'admin123') {
            return res.json({ success: true, message: 'Redirecting...', redirect: 'http://localhost:4000/login.html' });
        }
        const [users] = await dbPatient.promise().query('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) return res.status(401).json({ success: false, message: 'User not found' });
        const isMatch = await bcrypt.compare(password, users[0].password);
        if (isMatch) return res.json({ success: true, message: 'Success!', redirect: '/patient/Patient_Dashboard.html' });
        else return res.status(401).json({ success: false, message: 'Wrong password' });
    } catch (e) { res.status(500).json({ success: false, message: 'Server error' }); }
});

appPublic.get('/api/doctors', async (req, res) => {
    try {
        const { specialization, name } = req.query;
        let query = `
            SELECT DoctorID as id, FirstName as first_name, LastName as last_name, 
            Department as department, DoctorType as doctor_type, Specialization as specialization, 
            Fees as fees, ContactNumber as phone, Email as email, image_url, ActiveStatus as is_active 
            FROM doctors WHERE 1=1
        `;
        const params = [];
        if (specialization) { query += ' AND (Department LIKE ? OR Specialization LIKE ?)'; params.push(`%${specialization}%`, `%${specialization}%`); }
        if (name) { query += ' AND (CONCAT(FirstName, " ", LastName) LIKE ?)'; params.push(`%${name}%`); }
        query += ' ORDER BY DoctorID DESC';
        const [rows] = await dbDoctor.promise().query(query, params);
        res.json({ doctors: rows });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// START
appPublic.listen(3000, () => console.log(`✅ Patient Server: http://localhost:3000`));
appAdmin.listen(4000, () => console.log(`✅ Admin Server:   http://localhost:4000/login.html`));